# res://addons/godot-stat-math/core/sampling_gen.gd
class_name SamplingGen extends RefCounted

## Advanced Sampling and Quasi-Random Number Generation
##
## This class provides sophisticated sampling methods including quasi-random sequences, 
## Latin hypercube sampling, and coordinated shuffling for statistical simulations.
## Designed for high-performance multi-dimensional sampling with threading support.
##
## Features:
##
## * Quasi-random sequences (Sobol, Halton) for low-discrepancy sampling
##
## * Latin Hypercube sampling for space-filling designs
##
## * Coordinated shuffling with statistical guarantees
##
## * Memory pooling and threading for performance optimization
##
## * Multiple selection strategies (with/without replacement)

## Defines the available sampling methods for generating random sequences.
enum SamplingMethod {
	RANDOM,           ## Pseudo-random sampling using standard RNG
	SOBOL,            ## Sobol quasi-random sequence for low-discrepancy
	SOBOL_RANDOM,     ## Randomized Sobol sequence combining QMC benefits with randomization
	HALTON,           ## Halton quasi-random sequence based on prime numbers
	HALTON_RANDOM,    ## Randomized Halton sequence with random offsets
	LATIN_HYPERCUBE   ## Latin Hypercube space-filling design for stratified sampling
}

## Defines strategies for selecting samples from populations.
enum SelectionStrategy {
	WITH_REPLACEMENT,          ## Allow duplicates (bootstrap sampling, rolling dice)
	FISHER_YATES,              ## Without replacement using Fisher-Yates shuffle
	RESERVOIR,                 ## Without replacement using reservoir algorithm
	SELECTION_TRACKING         ## Without replacement with memory-efficient tracking
}

const _SOBOL_DATA = preload("res://addons/godot-stat-math/tables/sobol_data.gd")
const _PRIME_DATA = preload("res://addons/godot-stat-math/tables/prime_numbers_data.gd")
const _SOBOL_BITS: int = 30
const _SOBOL_MAX_VAL_FLOAT: float = float(1 << _SOBOL_BITS)

# Enhanced Sobol direction vectors system using authoritative Joe-Kuo data
# Supports up to 1024 dimensions with optimal low-discrepancy properties
static var _sobol_direction_vectors_cache: Dictionary = {}  # dimension -> Array[int]
static var _max_cached_dimension: int = -1

# Threading is always used for multi-dimensional generation (dimensions >= 3)

# Memory pooling for performance optimization
static var _deck_pool: Dictionary = {}  # deck_size -> Array[Array[int]]
static var _pool_mutex: Mutex = Mutex.new()

# Pool configuration
const MAX_POOLED_DECKS_PER_SIZE: int = 16

func _init() -> void:
	var start_time: int = Time.get_ticks_usec()
	_ensure_sobol_vectors_initialized(_SOBOL_DATA.get_max_dimension())  # Initialize all available dimensions
	var end_time: int = Time.get_ticks_usec()
	var duration_ms: float = (end_time - start_time) / 1000.0
	print("SamplingGen: Initialized %d Sobol dimensions in %.2f ms" % [_SOBOL_DATA.get_max_dimension(), duration_ms])


# --- MEMORY POOL MANAGEMENT ---
# Only deck pooling is implemented - provides significant performance gains
# for shuffle operations without the complexity of full sample pooling

## Gets a deck array from the pool or creates a new one
static func _get_pooled_deck(deck_size: int) -> Array[int]:
	_pool_mutex.lock()
	
	var pool_key: int = deck_size
	if not _deck_pool.has(pool_key):
		_deck_pool[pool_key] = []
	
	var deck_array_pool: Array = _deck_pool[pool_key]
	var deck: Array[int]
	
	if deck_array_pool.size() > 0:
		deck = deck_array_pool.pop_back() as Array[int]
		_pool_mutex.unlock()
		# Reset deck to default state [0, 1, 2, ..., deck_size-1]
		for i in range(deck_size):
			deck[i] = i
	else:
		_pool_mutex.unlock()
		# Create new deck
		deck = []
		deck.resize(deck_size)
		for i in range(deck_size):
			deck[i] = i
	
	return deck


## Returns a deck array to the pool for reuse
static func _return_pooled_deck(deck: Array[int], deck_size: int) -> void:
	_pool_mutex.lock()
	
	var pool_key: int = deck_size
	if not _deck_pool.has(pool_key):
		_deck_pool[pool_key] = []
	
	var deck_array_pool: Array = _deck_pool[pool_key]
	
	# Only keep reasonable number of pooled decks per size
	if deck_array_pool.size() < MAX_POOLED_DECKS_PER_SIZE:
		deck_array_pool.append(deck)
	
	_pool_mutex.unlock()


## Ensures Sobol direction vectors are initialized up to the specified dimension.
## This method is idempotent and safe to call multiple times.
## SINGLE-THREADED: Should only be called from main thread before spawning workers.
static func _ensure_sobol_vectors_initialized(max_dimension: int) -> void:
	if max_dimension <= _max_cached_dimension:
		return
		
	var start_dim: int = max(_max_cached_dimension + 1, 0)
	
	for dim in range(start_dim, max_dimension + 1):
		# Only generate if not already in cache
		if not _sobol_direction_vectors_cache.has(dim):
			_generate_direction_vectors_for_dimension(dim)
	
	# Update the maximum cached dimension
	if max_dimension > _max_cached_dimension:
		_max_cached_dimension = max_dimension


## Generates direction vectors for a specific dimension using authoritative Joe-Kuo direction numbers.
static func _generate_direction_vectors_for_dimension(dimension: int) -> void:
	if _sobol_direction_vectors_cache.has(dimension):
		return
		
	var direction_vectors: Array[int] = []
	direction_vectors.resize(_SOBOL_BITS)
	
	if dimension == 0:
		# Special case for dimension 0: use powers of 2 for the first dimension
		for j in range(_SOBOL_BITS):
			direction_vectors[j] = 1 << (_SOBOL_BITS - 1 - j)
	elif dimension == 1:
		# Special case for dimension 1: simple alternating pattern
		for j in range(_SOBOL_BITS):
			direction_vectors[j] = 1 << (_SOBOL_BITS - 1 - j)
			if j % 2 == 1:
				direction_vectors[j] = 0
	else:
		# Use authoritative Joe-Kuo direction numbers from SobolData
		if not _SOBOL_DATA.has_dimension(dimension):
			printerr("SamplingGen: No direction numbers available for dimension ", dimension)
			return
		
		var direction_numbers: Array = _SOBOL_DATA.get_direction_numbers(dimension)
		if direction_numbers.is_empty():
			printerr("SamplingGen: Empty direction numbers for dimension ", dimension)
			return
		
		# Convert direction numbers (m_i values) to direction vectors (V_i = m_i / 2^i)
		# First, set the initial direction vectors from the direction numbers
		for i in range(min(direction_numbers.size(), _SOBOL_BITS)):
			var m_i: int = direction_numbers[i]
			# Convert m_i to direction vector: V_i = m_i / 2^(i+1) represented as integer
			# Since we work with integer representation: V_i = m_i * 2^(_SOBOL_BITS - i - 1)
			direction_vectors[i] = m_i << (_SOBOL_BITS - i - 1)
		
		# If we need more direction vectors, generate them using recurrence relation
		# This should rarely be needed with proper Joe-Kuo data
		var s: int = direction_numbers.size()
		for j in range(s, _SOBOL_BITS):
			# Use a simple doubling pattern as fallback
			if j - s >= 0:
				direction_vectors[j] = direction_vectors[j - s] << 1
				if direction_vectors[j] >= (1 << _SOBOL_BITS):
					direction_vectors[j] = direction_vectors[j] ^ (1 << _SOBOL_BITS) ^ 1
	
	_sobol_direction_vectors_cache[dimension] = direction_vectors


# --- THREADED DIMENSION GENERATION ---

## Data structure for passing parameters to worker threads
class SobolDimensionTask:
	var dimension: int
	var n_draws: int  
	var starting_index: int
	var method: SamplingMethod
	var random_mask: int = 0  # For SOBOL_RANDOM
	var halton_base: int = 2  # For HALTON
	var random_offset: float = 0.0  # For HALTON_RANDOM
	var result_samples: Array[float] = []  # Store results here
	
	func _init(dim: int, draws: int, start_idx: int, sampling_method: SamplingMethod):
		dimension = dim
		n_draws = draws
		starting_index = start_idx
		method = sampling_method
		result_samples.resize(draws)


## Thread worker function for generating a single dimension's samples
static func _generate_dimension_samples_worker(task: SobolDimensionTask) -> void:
	match task.method:
		SamplingMethod.RANDOM:
			# Each thread needs its own RNG with deterministic seeding
			var thread_rng = RandomNumberGenerator.new()
			thread_rng.seed = hash(str(task.dimension) + str(task.starting_index))
			for i in range(task.n_draws):
				task.result_samples[i] = thread_rng.randf()
				
		SamplingMethod.SOBOL:
			var sobol_samples = _generate_sobol_1d(task.n_draws, task.dimension, task.starting_index)
			var has_errors: bool = false
			for i in range(task.n_draws):
				if i < sobol_samples.size() and sobol_samples[i] != -1.0:
					task.result_samples[i] = sobol_samples[i]
				else:
					has_errors = true
					break
			
			# Fallback to random if Sobol sequence hits limits
			if has_errors:
				print("SOBOL fallback for dimension ", task.dimension, " due to sequence limits")
				var fallback_rng = RandomNumberGenerator.new()
				fallback_rng.seed = hash(str(task.dimension) + str(task.starting_index) + "fallback")
				for i in range(task.n_draws):
					task.result_samples[i] = fallback_rng.randf()
				
		SamplingMethod.SOBOL_RANDOM:
			var sobol_integers = _get_sobol_1d_integers(task.n_draws, task.dimension, task.starting_index)
			var has_errors: bool = false
			for i in range(task.n_draws):
				if i < sobol_integers.size() and sobol_integers[i] != -1:
					task.result_samples[i] = float(sobol_integers[i] ^ task.random_mask) / _SOBOL_MAX_VAL_FLOAT
				else:
					has_errors = true
					break
			
			# Fallback to random if Sobol sequence hits limits
			if has_errors:
				print("SOBOL_RANDOM fallback for dimension ", task.dimension, " due to sequence limits")
				var fallback_rng = RandomNumberGenerator.new()
				fallback_rng.seed = hash(str(task.dimension) + str(task.starting_index) + "fallback")
				for i in range(task.n_draws):
					task.result_samples[i] = fallback_rng.randf()
					
		SamplingMethod.HALTON:
			var halton_samples = _generate_halton_1d(task.n_draws, task.halton_base, task.starting_index)
			for i in range(task.n_draws):
				task.result_samples[i] = halton_samples[i] if i < halton_samples.size() else -1.0
				
		SamplingMethod.HALTON_RANDOM:
			var halton_samples = _generate_halton_1d(task.n_draws, task.halton_base, task.starting_index)
			for i in range(task.n_draws):
				if halton_samples[i] != -1.0:
					task.result_samples[i] = fmod(halton_samples[i] + task.random_offset, 1.0)
				else:
					task.result_samples[i] = -1.0
		
		SamplingMethod.LATIN_HYPERCUBE:
			# Each thread needs its own RNG for LHS
			var thread_rng = RandomNumberGenerator.new()
			thread_rng.seed = hash(str(task.dimension) + str(task.starting_index))
			var lhs_samples = _generate_latin_hypercube_1d(task.n_draws, thread_rng)
			for i in range(task.n_draws):
				task.result_samples[i] = lhs_samples[i] if i < lhs_samples.size() else -1.0
		
		_:
			# For unsupported methods, fill with -1.0
			for i in range(task.n_draws):
				task.result_samples[i] = -1.0


## Threaded version of generate_samples_nd for high-dimensional cases
static func _generate_samples_nd(
	n_draws: int, 
	dimensions: int, 
	method: SamplingMethod,
	starting_index: int,
	rng: RandomNumberGenerator
) -> Array:
	var samples: Array = []
	samples.resize(n_draws)
	for i in range(n_draws):
		samples[i] = []
		samples[i].resize(dimensions)
	
	# Check for practical limits with Sobol sequences
	var max_sobol_index: int = (1 << _SOBOL_BITS) - 1  # 2^30 - 1
	var total_sequence_length: int = n_draws + starting_index
	
	if (method == SamplingMethod.SOBOL or method == SamplingMethod.SOBOL_RANDOM) and total_sequence_length > max_sobol_index:
		print("WARNING: Sobol sequence request (", total_sequence_length, ") exceeds practical limit (", max_sobol_index, "). Consider using RANDOM method for very large batches.")
	
	# Pre-initialize ALL Sobol dimensions needed BEFORE spawning threads
	# This ensures true parallelization - threads only READ, never write to cache
	if method == SamplingMethod.SOBOL or method == SamplingMethod.SOBOL_RANDOM:
		_ensure_sobol_vectors_initialized(dimensions - 1)
	
	# Pre-generate random values for methods that need them
	var random_masks: Array = []
	var random_offsets: Array = []
	
	if method == SamplingMethod.SOBOL_RANDOM:
		random_masks.resize(dimensions)
		for d in range(dimensions):
			random_masks[d] = rng.randi() & ((1 << _SOBOL_BITS) - 1)
	
	if method == SamplingMethod.HALTON_RANDOM:
		random_offsets.resize(dimensions)
		for d in range(dimensions):
			random_offsets[d] = rng.randf()
	
	# Create tasks for each dimension
	var tasks: Array = []
	for d in range(dimensions):
		var task = SobolDimensionTask.new(d, n_draws, starting_index, method)
		
		match method:
			SamplingMethod.SOBOL_RANDOM:
				task.random_mask = random_masks[d]
			SamplingMethod.HALTON:
				task.halton_base = _get_nth_prime(d)
			SamplingMethod.HALTON_RANDOM:
				task.halton_base = _get_nth_prime(d)
				task.random_offset = random_offsets[d]
			# RANDOM and LATIN_HYPERCUBE handled via deterministic thread seeding
		
		tasks.append(task)
	
	# Submit tasks to thread pool
	var task_ids: Array = []
	for task in tasks:
		var task_id = WorkerThreadPool.add_task(Callable(_generate_dimension_samples_worker).bind(task))
		task_ids.append(task_id)
	
	# Wait for all tasks to complete first (parallel execution)
	for task_id in task_ids:
		WorkerThreadPool.wait_for_task_completion(task_id)
	
	# Then collect results from all completed tasks
	for d in range(dimensions):
		var dim_samples: Array[float] = tasks[d].result_samples
		for i in range(n_draws):
			samples[i][d] = dim_samples[i] if i < dim_samples.size() else -1.0
	
	return samples


## Data structure for batch shuffle processing with pre-generated samples
class BatchShuffleTask:
	var deck_size: int
	var chunk_size: int
	var sample_slice: Array = []  # Pre-generated samples for this chunk
	var result_shuffles: Array = []  # Store multiple shuffle results here
	
	func _init(size: int, n_shuffles: int, samples: Array):
		deck_size = size
		chunk_size = n_shuffles
		sample_slice = samples
		result_shuffles.resize(n_shuffles)


## Optimized two-phase batch shuffle generation
## Phase 1: Multi-threaded bulk sample generation
## Phase 2: Multi-threaded shuffling with pre-generated samples
static func _coordinated_batch_shuffles_threaded(
	deck_size: int,
	n_shuffles: int,
	method: SamplingMethod,
	starting_index: int,
	sample_seed: int
) -> Array:
	var shuffle_dimensions: int = deck_size - 1
	if shuffle_dimensions <= 0:
		# Handle trivial case
		var results: Array = []
		results.resize(n_shuffles)
		for i in range(n_shuffles):
			var deck: Array[int] = []
			if deck_size == 1:
				deck.append(0)
			results[i] = deck
		return results
	
	var rng_to_use: RandomNumberGenerator = StatMath.get_rng()
	if sample_seed != -1:
		rng_to_use.seed = sample_seed
	
	# PHASE 1: Multi-threaded bulk sample generation for ALL shuffles
	var all_samples: Array = _generate_samples_nd(
		n_shuffles, 
		shuffle_dimensions, 
		method, 
		starting_index, 
		rng_to_use
	)
	
	# PHASE 2: Multi-threaded shuffling with pre-generated samples
	var results: Array = []
	results.resize(n_shuffles)
	
	# Determine optimal thread count for shuffle processing
	var thread_count: int = min(OS.get_processor_count(), n_shuffles)
	var shuffles_per_thread: int = ceili(float(n_shuffles) / float(thread_count))
	
	# Adjust for small batches - don't over-thread
	if n_shuffles < thread_count * 2:
		thread_count = max(1, n_shuffles / 2)
		shuffles_per_thread = ceili(float(n_shuffles) / float(thread_count))
	
	var shuffle_tasks: Array = []
	var task_ids: Array = []
	
	# Create shuffle tasks with sample slices
	for thread_idx in range(thread_count):
		var start_shuffle: int = thread_idx * shuffles_per_thread
		var end_shuffle: int = min(start_shuffle + shuffles_per_thread, n_shuffles)
		
		if start_shuffle >= end_shuffle:
			break  # No more work for this thread
		
		var actual_chunk_size: int = end_shuffle - start_shuffle
		
		# Extract sample slice for this chunk
		var sample_slice: Array = []
		sample_slice.resize(actual_chunk_size)
		for i in range(actual_chunk_size):
			var sample_idx: int = start_shuffle + i
			if sample_idx < all_samples.size():
				sample_slice[i] = all_samples[sample_idx]
			else:
				# Fallback for edge case
				sample_slice[i] = []
				sample_slice[i].resize(shuffle_dimensions)
				for d in range(shuffle_dimensions):
					sample_slice[i][d] = 0.5  # Default value
		
		var task = BatchShuffleTask.new(deck_size, actual_chunk_size, sample_slice)
		shuffle_tasks.append(task)
		
		var task_id = WorkerThreadPool.add_task(Callable(_batch_shuffle_worker).bind(task))
		task_ids.append(task_id)
	
	# Wait for all shuffle tasks to complete
	for task_id in task_ids:
		WorkerThreadPool.wait_for_task_completion(task_id)
	
	# Assemble results from all completed shuffle tasks
	for i in range(shuffle_tasks.size()):
		var chunk_results: Array = shuffle_tasks[i].result_shuffles
		var start_idx: int = i * shuffles_per_thread
		
		# Copy chunk results to final results array
		for j in range(chunk_results.size()):
			var result_idx: int = start_idx + j
			if result_idx < results.size():
				results[result_idx] = chunk_results[j]
	
	return results


## Simplified worker function that only does shuffling with pre-generated samples
## No sample generation needed - samples are pre-generated in Phase 1
static func _batch_shuffle_worker(task: BatchShuffleTask) -> void:
	# Simply process each shuffle with its pre-generated samples
	for i in range(task.chunk_size):
		if i < task.sample_slice.size():
			task.result_shuffles[i] = _coordinated_shuffle_with_samples(
				task.deck_size, 
				task.sample_slice[i]
			)
		else:
			# Fallback on error
			task.result_shuffles[i] = _create_unshuffled_deck(task.deck_size)


## Helper function to create an unshuffled deck for error cases
static func _create_unshuffled_deck(deck_size: int) -> Array[int]:
	# Use pooled deck array for performance
	return _get_pooled_deck(deck_size)


## Optimized shuffle using pre-generated samples - avoids redundant sample generation
static func _coordinated_shuffle_with_samples(deck_size: int, sobol_point: Array) -> Array[int]:
	if deck_size <= 1:
		var result: Array[int] = []
		if deck_size == 1:
			result.append(0)
		return result
	
	# Use pooled deck array for performance
	var deck: Array[int] = _get_pooled_deck(deck_size)
	
	# Perform coordinated Fisher-Yates shuffle using the pre-generated N-dimensional point
	for i in range(deck_size - 1, 0, -1):
		var dim_index: int = deck_size - 1 - i
		var raw_random_val: float = sobol_point[dim_index] if dim_index < sobol_point.size() else 0.5
		
		# Direct uniform mapping ensures proper distribution across the deck
		var j: int = int(raw_random_val * float(i + 1))
		j = clamp(j, 0, i)  # Ensure j is always in valid range [0, i]
		
		# Swap deck[i] and deck[j]
		if i != j:
			var temp: int = deck[i]
			deck[i] = deck[j]
			deck[j] = temp
	
	# Note: We don't return the deck to pool here since it's being returned as result
	# The caller is responsible for the returned array
	return deck


## Worker function for individual shuffle generation
static func _coordinated_shuffle_worker(task: BatchShuffleTask) -> void:
	task.result_shuffle = coordinated_shuffle(
		task.deck_size, 
		task.method, 
		task.point_index, 
		task.sample_seed
	)


# --- CONTINUOUS SPACE SAMPLING (for Monte Carlo, space-filling) ---

## Unified interface for generating samples in 1, 2, or N dimensions.
##
## Returns different types based on dimensions: [code]Array[float][/code] for 1D, 
## [code]Array[Vector2][/code] for 2D, [code]Array[Array[float]][/code] for N-D.
## Supports all sampling methods including quasi-random sequences.
##
## Mathematical Note: For quasi-random methods, low-discrepancy sequences provide better coverage than pseudo-random
static func generate_samples(
	n_draws: int, 
	dimensions: int = 1,
	method: SamplingMethod = SamplingMethod.RANDOM, 
	starting_index: int = 0,
	sample_seed: int = -1
) -> Variant:
	if n_draws < 0:
		push_error("n_draws must be non-negative. Received: " + str(n_draws))
		return null
	
	if dimensions < 1:
		push_error("dimensions must be >= 1. Received: " + str(dimensions))
		return null
	
	if n_draws == 0:
		match dimensions:
			1: return Array([], TYPE_FLOAT, "", null)
			2: return Array([], TYPE_VECTOR2, "", null)
			_: return Array([], TYPE_ARRAY, "", null)
	
	# Use the unified N-dimensional generation for all cases
	var nd_samples: Array = generate_samples_nd(n_draws, dimensions, method, starting_index, sample_seed)
	
	match dimensions:
		1:
			# Convert from Array[Array[float]] to Array[float]
			var samples_1d: Array[float] = []
			samples_1d.resize(n_draws)
			for i in range(n_draws):
				if i < nd_samples.size() and nd_samples[i].size() > 0:
					samples_1d[i] = nd_samples[i][0]
				else:
					samples_1d[i] = -1.0  # Error signal
			return samples_1d
		2:
			# Convert from Array[Array[float]] to Array[Vector2]
			var samples_2d: Array[Vector2] = []
			samples_2d.resize(n_draws)
			for i in range(n_draws):
				if i < nd_samples.size() and nd_samples[i].size() >= 2:
					samples_2d[i] = Vector2(nd_samples[i][0], nd_samples[i][1])
				else:
					samples_2d[i] = Vector2(-1.0, -1.0)  # Error signal
			return samples_2d
		_:
			# Return the N-dimensional array as-is
			return nd_samples


## Generates N-dimensional samples using the specified method.
##
## Returns an array of samples where each sample is an array of [code]dimensions[/code] values.
## Uses threading for dimensions ≥ 3 for optimal performance. Supports all sampling methods.
##
## Mathematical Note: Quasi-random sequences maintain uniformity across all dimensions simultaneously
static func generate_samples_nd(
	n_draws: int, 
	dimensions: int, 
	method: SamplingMethod = SamplingMethod.RANDOM,
	starting_index: int = 0,
	sample_seed: int = -1
) -> Array:
	var samples: Array = []
	if n_draws <= 0 or dimensions <= 0:
		return samples
	
	var rng_to_use: RandomNumberGenerator = StatMath.get_rng()
	if sample_seed != -1:
		rng_to_use.seed = sample_seed
	
	# Pre-initialize Sobol dimensions if needed
	if method == SamplingMethod.SOBOL or method == SamplingMethod.SOBOL_RANDOM:
		_ensure_sobol_vectors_initialized(dimensions - 1)
	
	# Always use threading for dimensions >= 3 (cleaner, simpler, and faster)
	if dimensions >= 3:
		return _generate_samples_nd(n_draws, dimensions, method, starting_index, rng_to_use)
	
	# Keep simple sequential implementation only for 1D and 2D cases
	samples.resize(n_draws)
	for i in range(n_draws):
		samples[i] = []
		samples[i].resize(dimensions)
	
	match method:
		SamplingMethod.RANDOM:
			for i in range(n_draws):
				for d in range(dimensions):
					samples[i][d] = rng_to_use.randf()
		
		SamplingMethod.SOBOL:
			for d in range(dimensions):
				var dim_samples = _generate_sobol_1d(n_draws, d, starting_index)
				var has_errors: bool = false
				for i in range(n_draws):
					if i < dim_samples.size() and dim_samples[i] != -1.0:
						samples[i][d] = dim_samples[i]
					else:
						has_errors = true
						break
				
				# Fallback to random if Sobol sequence hits limits
				if has_errors:
					print("SOBOL fallback for dimension ", d, " due to sequence limits")
					for i in range(n_draws):
						samples[i][d] = rng_to_use.randf()
		
		SamplingMethod.SOBOL_RANDOM:
			var random_masks = []
			random_masks.resize(dimensions)
			for d in range(dimensions):
				random_masks[d] = rng_to_use.randi() & ((1 << _SOBOL_BITS) - 1)
			
			for d in range(dimensions):
				var sobol_integers = _get_sobol_1d_integers(n_draws, d, starting_index)
				var has_errors: bool = false
				for i in range(n_draws):
					if i < sobol_integers.size() and sobol_integers[i] != -1:
						samples[i][d] = float(sobol_integers[i] ^ random_masks[d]) / _SOBOL_MAX_VAL_FLOAT
					else:
						has_errors = true
						break
				
				# Fallback to random if Sobol sequence hits limits
				if has_errors:
					print("SOBOL_RANDOM fallback for dimension ", d, " due to sequence limits")
					for i in range(n_draws):
						samples[i][d] = rng_to_use.randf()
		
		SamplingMethod.HALTON:
			for d in range(dimensions):
				var base: int = _get_nth_prime(d)
				var dim_samples = _generate_halton_1d(n_draws, base, starting_index)
				for i in range(n_draws):
					samples[i][d] = dim_samples[i] if i < dim_samples.size() else -1.0
		
		SamplingMethod.HALTON_RANDOM:
			var random_offsets = []
			random_offsets.resize(dimensions)
			for d in range(dimensions):
				random_offsets[d] = rng_to_use.randf()
			
			for d in range(dimensions):
				var base: int = _get_nth_prime(d)
				var halton_samples = _generate_halton_1d(n_draws, base, starting_index)
				for i in range(n_draws):
					if halton_samples[i] != -1.0:
						samples[i][d] = fmod(halton_samples[i] + random_offsets[d], 1.0)
					else:
						samples[i][d] = rng_to_use.randf()
		
		SamplingMethod.LATIN_HYPERCUBE:
			for d in range(dimensions):
				var lhs_samples = _generate_latin_hypercube_1d(n_draws, rng_to_use)
				for i in range(n_draws):
					samples[i][d] = lhs_samples[i] if i < lhs_samples.size() else -1.0
		
		_:
			push_error("Unsupported sampling method: " + str(SamplingMethod.keys()[method]))
			for i in range(n_draws):
				for d in range(dimensions):
					samples[i][d] = -1.0
	
	return samples


## Performs a complete coordinated shuffle using multi-dimensional sampling.
##
## Uses a single multi-dimensional point to drive the Fisher-Yates shuffle algorithm,
## ensuring statistical guarantees across the entire shuffle operation. 
## This is the core method for coordinated shuffling.
##
## Mathematical Note: Uses [code](deck_size-1)[/code] dimensional point for Fisher-Yates coordination
static func coordinated_shuffle(
	deck_size: int, 
	method: SamplingMethod = SamplingMethod.SOBOL,
	point_index: int = 0,
	sample_seed: int = -1
) -> Array[int]:
	if deck_size <= 1:
		var result: Array[int] = []
		if deck_size == 1:
			result.append(0)
		return result
	
	var rng_to_use: RandomNumberGenerator = StatMath.get_rng()
	if sample_seed != -1:
		rng_to_use.seed = sample_seed
	
	var deck: Array[int] = []
	deck.resize(deck_size)
	for i in range(deck_size):
		deck[i] = i
	
	# Generate a multi-dimensional point for the shuffle
	# We need (deck_size - 1) dimensions for Fisher-Yates
	var shuffle_dimensions: int = deck_size - 1
	
	# Pre-initialize Sobol dimensions if needed
	if method == SamplingMethod.SOBOL or method == SamplingMethod.SOBOL_RANDOM:
		_ensure_sobol_vectors_initialized(shuffle_dimensions - 1)
	
	# Generate a single multi-dimensional point using multithreading
	var nd_samples: Array = _generate_samples_nd(1, shuffle_dimensions, method, point_index, rng_to_use)
	
	if nd_samples.is_empty() or nd_samples[0].size() != shuffle_dimensions:
		push_error("Failed to generate ND samples for coordinated shuffle")
		return deck  # Return unshuffled deck on error
	
	var sobol_point = nd_samples[0]
	
	# Perform coordinated Fisher-Yates shuffle using the N-dimensional point
	for i in range(deck_size - 1, 0, -1):
		var dim_index: int = deck_size - 1 - i
		var raw_random_val: float = sobol_point[dim_index]
		
		# Direct uniform mapping ensures proper distribution across the deck
		var j: int = int(raw_random_val * float(i + 1))
		j = clamp(j, 0, i)  # Ensure j is always in valid range [0, i]
		
		# Swap deck[i] and deck[j]
		if i != j:
			var temp: int = deck[i]
			deck[i] = deck[j]
			deck[j] = temp
	
	return deck


## Generates multiple coordinated shuffles efficiently.
##
## Creates multiple shuffles using sequential points from the specified sampling sequence.
## Uses threading for [code]n_shuffles ≥ 2[/code] to maximize performance with batch operations.
##
## Mathematical Note: Each shuffle uses consecutive points from the quasi-random sequence for coordination
static func coordinated_batch_shuffles(
	deck_size: int,
	n_shuffles: int, 
	method: SamplingMethod = SamplingMethod.SOBOL,
	starting_index: int = 0,
	sample_seed: int = -1
) -> Array:
	var results: Array = []
	if n_shuffles <= 0 or deck_size <= 0:
		return results
	
	# Fast path for RANDOM method - no need for complex ND generation
	if method == SamplingMethod.RANDOM:
		return _fast_random_batch_shuffles(deck_size, n_shuffles, sample_seed)
	
	# Always use threading for batch operations (simpler and faster)
	if n_shuffles >= 2:
		return _coordinated_batch_shuffles_threaded(deck_size, n_shuffles, method, starting_index, sample_seed)
	
	# Single shuffle case
	results.resize(n_shuffles)
	for i in range(n_shuffles):
		results[i] = coordinated_shuffle(deck_size, method, starting_index + i, sample_seed)
	
	return results


# --- DISCRETE INDEX SAMPLING (for finite populations, card games, bootstrap) ---

## Samples indices from a finite population using advanced selection strategies.
##
## Combines sampling methods (how to generate random numbers) with selection strategies 
## (how to use those numbers for population sampling). Supports both replacement and 
## non-replacement sampling with various optimization strategies.
##
## Mathematical Note: Selection strategies optimize for different use cases - bootstrap (with replacement), surveys (without replacement)
static func sample_indices(
	population_size: int, 
	draw_count: int, 
	selection_strategy: SelectionStrategy = SelectionStrategy.FISHER_YATES,
	sampling_method: SamplingMethod = SamplingMethod.RANDOM,
	sample_seed: int = -1
) -> Array[int]:
	if draw_count < 0:
		push_error("draw_count cannot be negative. Received: " + str(draw_count))
		return []
	if population_size < 0:
		push_error("population_size cannot be negative. Received: " + str(population_size))
		return []
	if population_size == 0:
		push_error("population_size must be positive. Received: " + str(population_size))
		return []
	if selection_strategy != SelectionStrategy.WITH_REPLACEMENT and draw_count > population_size:
		push_error("Without replacement, draw_count cannot exceed population_size. Received draw_count=" + str(draw_count) + ", population_size=" + str(population_size))
		return []

	var rng_to_use: RandomNumberGenerator = StatMath.get_rng()
	if sample_seed != -1:
		rng_to_use.seed = sample_seed

	match selection_strategy:
		SelectionStrategy.WITH_REPLACEMENT:
			return _with_replacement_draw(population_size, draw_count, sampling_method, rng_to_use)
		SelectionStrategy.FISHER_YATES:
			return _fisher_yates_draw(population_size, draw_count, sampling_method, rng_to_use)
		SelectionStrategy.RESERVOIR:
			return _reservoir_draw(population_size, draw_count, sampling_method, rng_to_use)
		SelectionStrategy.SELECTION_TRACKING:
			return _selection_tracking_draw(population_size, draw_count, sampling_method, rng_to_use)
	
	push_error("Unsupported selection strategy: " + str(SelectionStrategy.keys()[selection_strategy]))
	return []


# --- PRIVATE IMPLEMENTATION METHODS ---

## Sampling with replacement - allows duplicates.
static func _with_replacement_draw(population_size: int, draw_count: int, sampling_method: SamplingMethod, rng: RandomNumberGenerator) -> Array[int]:
	var result: Array[int] = []
	if draw_count <= 0:
		return result
	result.resize(draw_count)

	# Generate random values using the specified sampling method
	var random_values: Array[float] = []
	match sampling_method:
		SamplingMethod.RANDOM:
			random_values.resize(draw_count)
			for i in range(draw_count):
				random_values[i] = rng.randf()
		SamplingMethod.SOBOL:
			random_values = _generate_sobol_1d(draw_count, 0)
		SamplingMethod.SOBOL_RANDOM:
			var sobol_integers: Array[int] = _get_sobol_1d_integers(draw_count, 0)
			var random_mask: int = rng.randi() & ((1 << _SOBOL_BITS) - 1)
			random_values.resize(draw_count)
			for i in range(draw_count):
				if sobol_integers[i] != -1:
					random_values[i] = float(sobol_integers[i] ^ random_mask) / _SOBOL_MAX_VAL_FLOAT
				else:
					random_values[i] = rng.randf() # Fallback on error
		SamplingMethod.HALTON:
			random_values = _generate_halton_1d(draw_count, 2)
		SamplingMethod.HALTON_RANDOM:
			var halton_samples: Array[float] = _generate_halton_1d(draw_count, 2)
			var random_offset: float = rng.randf()
			random_values.resize(draw_count)
			for i in range(draw_count):
				if halton_samples[i] != -1.0:
					random_values[i] = fmod(halton_samples[i] + random_offset, 1.0)
				else:
					random_values[i] = rng.randf() # Fallback on error
		SamplingMethod.LATIN_HYPERCUBE:
			random_values = _generate_latin_hypercube_1d(draw_count, rng)
		_:
			# Fallback to RANDOM
			random_values.resize(draw_count)
			for i in range(draw_count):
				random_values[i] = rng.randf()

	# Convert random values to indices
	for i in range(draw_count):
		result[i] = int(random_values[i] * float(population_size)) % population_size

	return result


## Fisher-Yates shuffle with custom sampling method for randomness.
static func _fisher_yates_draw(population_size: int, draw_count: int, sampling_method: SamplingMethod, rng: RandomNumberGenerator) -> Array[int]:
	var deck: Array[int] = []
	deck.resize(population_size)
	for i in range(population_size):
		deck[i] = i
	
	# Generate enough random values for the shuffle
	var random_values: Array[float] = []
	match sampling_method:
		SamplingMethod.RANDOM:
			# Generate on-demand for efficiency
			pass
		_:
			# Pre-generate for deterministic sequences
			var samples_variant: Variant = generate_samples(draw_count, 1, sampling_method, 0, rng.get_seed() if rng.get_seed() != 0 else -1)
			random_values = samples_variant as Array[float]

	# Partial Fisher-Yates shuffle
	for i in range(draw_count):
		var random_val: float
		if random_values.is_empty():
			random_val = rng.randf()
		else:
			random_val = random_values[i] if i < random_values.size() else rng.randf()
		
		# Map to valid range [i, population_size - 1]
		var j: int = i + int(random_val * float(population_size - i))
		j = min(j, population_size - 1) # Clamp to prevent overflow
		
		# Swap
		if i != j:
			var temp: int = deck[i]
			deck[i] = deck[j]
			deck[j] = temp

	# Return first draw_count elements
	var result: Array[int] = []
	result.resize(draw_count)
	for i in range(draw_count):
		result[i] = deck[i]
	return result


## Reservoir sampling with custom sampling method.
static func _reservoir_draw(population_size: int, draw_count: int, sampling_method: SamplingMethod, rng: RandomNumberGenerator) -> Array[int]:
	var reservoir: Array[int] = []
	reservoir.resize(draw_count)
	
	if draw_count == 0:
		return reservoir

	# Fill reservoir with first draw_count items
	for i in range(min(draw_count, population_size)):
		reservoir[i] = i

	# Generate random values for the algorithm
	var needed_randoms: int = max(0, population_size - draw_count)
	var random_values: Array[float] = []
	if needed_randoms > 0:
		match sampling_method:
			SamplingMethod.RANDOM:
				# Generate on-demand for efficiency
				pass
			_:
				var samples_variant: Variant = generate_samples(needed_randoms, 1, sampling_method, 0, rng.get_seed() if rng.get_seed() != 0 else -1)
				random_values = samples_variant as Array[float]

	# Reservoir algorithm
	var random_index: int = 0
	for i in range(draw_count, population_size):
		var random_val: float
		if random_values.is_empty():
			random_val = rng.randf()
		else:
			random_val = random_values[random_index] if random_index < random_values.size() else rng.randf()
			random_index += 1
		
		var j: int = int(random_val * float(i + 1))
		if j < draw_count:
			reservoir[j] = i

	return reservoir


## Selection tracking with custom sampling method.
static func _selection_tracking_draw(population_size: int, draw_count: int, sampling_method: SamplingMethod, rng: RandomNumberGenerator) -> Array[int]:
	var selected_indices: Dictionary = {}
	var result: Array[int] = []
	result.resize(draw_count)
	
	if draw_count == 0:
		return result

	# Pre-generate random values for deterministic sequences
	var max_attempts: int = (population_size * 4) + (draw_count * 4) + 20
	var random_values: Array[float] = []
	match sampling_method:
		SamplingMethod.RANDOM:
			# Generate on-demand
			pass
		_:
			var samples_variant: Variant = generate_samples(max_attempts, 1, sampling_method, 0, rng.get_seed() if rng.get_seed() != 0 else -1)
			random_values = samples_variant as Array[float]

	var items_drawn: int = 0
	var attempts: int = 0

	while items_drawn < draw_count and attempts < max_attempts:
		var random_val: float
		if random_values.is_empty():
			random_val = rng.randf()
		else:
			random_val = random_values[attempts] if attempts < random_values.size() else rng.randf()
		
		var random_index: int = int(random_val * float(population_size))
		if not selected_indices.has(random_index):
			selected_indices[random_index] = true
			result[items_drawn] = random_index
			items_drawn += 1
		attempts += 1
	
	if items_drawn < draw_count:
		push_error("Failed to draw enough unique items. Drew " + str(items_drawn) + " out of " + str(draw_count) + " requested.")
		return result.slice(0, items_drawn)

	return result


# --- SOBOL SEQUENCE IMPLEMENTATION ---

## Returns the nth prime number using the PrimeNumbersData table.
## Used for Halton sequence base selection.
static func _get_nth_prime(n: int) -> int:
	return _PRIME_DATA.get_nth_prime(n)


## Generates Sobol sequence integers for a specific dimension.
## ASSUMES: Direction vectors for dimension_index are already initialized.
static func _get_sobol_1d_integers(ndraws: int, dimension_index: int, starting_index: int = 0) -> Array[int]:
	var integers: Array[int] = []
	if ndraws <= 0:
		return integers
	integers.resize(ndraws)
	
	if dimension_index < 0 or dimension_index > _SOBOL_DATA.get_max_dimension():
		printerr("Sobol: Invalid dimension_index: ", dimension_index, " (max supported: ", _SOBOL_DATA.get_max_dimension(), ")")
		for i in range(ndraws): integers[i] = -1 # Signal error
		return integers

	# Retrieve the cached direction vectors for the specified dimension
	var direction_vectors: Array[int] = _sobol_direction_vectors_cache[dimension_index]
	
	# Check for reasonable bounds - Sobol sequences have practical limits
	var max_sobol_index: int = (1 << _SOBOL_BITS) - 1  # 2^30 - 1
	var total_needed: int = ndraws + starting_index
	
	if total_needed > max_sobol_index:
		printerr("Sobol: Requested sequence length (%d) exceeds maximum Sobol index (%d) for dimension %d" % [total_needed, max_sobol_index, dimension_index])
		for i in range(ndraws): integers[i] = -1 # Signal error
		return integers
	
	# Generate Sobol integers starting from starting_index
	var temp_integers: Array[int] = []
	temp_integers.resize(total_needed)
	
	var current_sobol_integer: int = 0
	if total_needed > 0:
		temp_integers[0] = 0 # First Sobol integer is 0

	for i in range(1, total_needed):
		var c: int = 0
		var temp_i: int = i
		
		# Count trailing zeros (ctz) - find rightmost 1 bit position
		while (temp_i & 1) == 0 and temp_i > 0:
			temp_i >>= 1
			c += 1
		
		# Ensure c is within bounds for direction_vectors
		if c >= direction_vectors.size(): 
			printerr("Sobol sequence ctz index c (%d) is out of range for direction_vectors.size() (%d) at point index i=%d for dim %d." % [c, direction_vectors.size(), i, dimension_index])
			# This is an error state; fill remaining integers and return to avoid further issues.
			for k in range(i, total_needed): 
				temp_integers[k] = -1 # Signal error from this point
			break
			
		current_sobol_integer = current_sobol_integer ^ direction_vectors[c]
		temp_integers[i] = current_sobol_integer
	
	# Extract the requested slice
	for i in range(ndraws):
		var source_index: int = starting_index + i
		if source_index < temp_integers.size() and temp_integers[source_index] != -1:
			integers[i] = temp_integers[source_index]
		else:
			integers[i] = -1  # Error signal
		
	return integers


## Generates 1D Sobol samples for a specific dimension.
static func _generate_sobol_1d(ndraws: int, dimension_index: int, starting_index: int = 0) -> Array[float]:
	var samples: Array[float] = []
	if ndraws <= 0:
		return samples
	samples.resize(ndraws)

	var sobol_integers: Array[int] = _get_sobol_1d_integers(ndraws, dimension_index, starting_index)
	# Check if _get_sobol_1d_integers signaled an error (by filling with -1)
	if ndraws > 0 and not sobol_integers.is_empty() and sobol_integers[0] == -1 and sobol_integers.count(-1) == ndraws:
		for i in range(ndraws): samples[i] = -1.0 # Propagate error
		return samples
		
	for i in range(ndraws):
		# Additional check for individual -1 in sobol_integers if partial error occurred
		if sobol_integers[i] == -1:
			samples[i] = -1.0
		else:
			samples[i] = float(sobol_integers[i]) / _SOBOL_MAX_VAL_FLOAT
		
	return samples


# --- HALTON SEQUENCE IMPLEMENTATION ---

static func _generate_halton_1d(ndraws: int, base: int, starting_index: int = 0) -> Array[float]:
	var sequence: Array[float] = []
	if ndraws <= 0: return sequence
	sequence.resize(ndraws)

	# Check for invalid base
	if base < 2:
		push_error("Halton base must be >= 2. Received: " + str(base))
		for i_idx in range(ndraws): sequence[i_idx] = -1.0 # Signal error
		return sequence

	for i_idx in range(ndraws):
		var n: int = i_idx + starting_index + 1 # Halton sequence is 1-indexed for generation
		var x: float = 0.0
		var f: float = 1.0
		while n > 0:
			f /= float(base)
			x += f * (n % base)
			n = int(n / base) # Ensure integer division
		sequence[i_idx] = x
	return sequence


# --- LATIN HYPERCUBE IMPLEMENTATION ---

static func _generate_latin_hypercube_1d(ndraws: int, rng: RandomNumberGenerator) -> Array[float]:
	var lhs_samples: Array[float] = []
	if ndraws <= 0:
		return lhs_samples
	lhs_samples.resize(ndraws)

	for i in range(ndraws):
		lhs_samples[i] = (float(i) + rng.randf()) / float(ndraws)
	
	# Fisher-Yates shuffle
	for i in range(ndraws - 1, 0, -1): 
		var j: int = rng.randi_range(0, i) 
		var temp: float = lhs_samples[i]
		lhs_samples[i] = lhs_samples[j]
		lhs_samples[j] = temp
		
	return lhs_samples


# Fast random batch shuffles
static func _fast_random_batch_shuffles(deck_size: int, n_shuffles: int, sample_seed: int) -> Array:
	var results: Array = []
	results.resize(n_shuffles)
	
	for i in range(n_shuffles):
		results[i] = _fast_random_shuffle(deck_size, sample_seed)
	
	return results


static func _fast_random_shuffle(deck_size: int, sample_seed: int) -> Array[int]:
	var deck: Array[int] = []
	deck.resize(deck_size)
	for i in range(deck_size):
		deck[i] = i
	
	# Fisher-Yates shuffle
	for i in range(deck_size - 1, 0, -1):
		var j: int = int(randf() * float(i + 1))
		var temp: int = deck[i]
		deck[i] = deck[j]
		deck[j] = temp
	
	return deck
